// pages/shoppingCart/shoppingCart.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    items: [
      { name: 'USA', value: '妈妈我能行勇敢做自己全套10册儿童情绪管理与性格培养绘本 中英文双语亲', images:'https://images.unsplash.com/photo-1551334787-21e6bd3ab135?w=640',picle:'￥45.60',del:'￥78.5'},
      { name: 'CHN', value: '妈妈我能行勇敢做自己全套10册儿童情绪管理与性格培养绘本 中英文双语亲', images: 'https://images.unsplash.com/photo-1551334787-21e6bd3ab135?w=640', picle: '￥45.60', del: '￥78.5', checked: 'true' },
      { name: 'BRA', value: '妈妈我能行勇敢做自己全套10册儿童情绪管理与性格培养绘本 中英文双语亲', images: 'https://images.unsplash.com/photo-1551334787-21e6bd3ab135?w=640', picle: '￥45.60', del: '￥78.5'},
      { name: 'JPN', value: '妈妈我能行勇敢做自己全套10册儿童情绪管理与性格培养绘本 中英文双语亲', images: 'https://images.unsplash.com/photo-1551334787-21e6bd3ab135?w=640', picle: '￥45.60', del: '￥78.5' }
    ],
    // input默认是1
    num: 1,
    // 使用data数据对象设置样式名
    minusStatus: 'disabled'
  },
  /* 点击减号 */
  bindMinus: function () {
    var num = this.data.num;
    // 如果大于1时，才可以减
    if (num > 1) {
      num--;
    }
    // 只有大于一件的时候，才能normal状态，否则disable状态
    var minusStatus = num <= 1 ? 'disabled' : 'normal';
    // 将数值与状态写回
    this.setData({
      num: num,
      minusStatus: minusStatus
    });
  },
  /* 点击加号 */
  bindPlus: function () {
    var num = this.data.num;
    // 不作过多考虑自增1
    num++;
    // 只有大于一件的时候，才能normal状态，否则disable状态
    var minusStatus = num < 1 ? 'disabled' : 'normal';
    // 将数值与状态写回
    this.setData({
      num: num,
      minusStatus: minusStatus
    });
  },
  /* 输入框事件 */
  bindManual: function (e) {
    var num = e.detail.value;
    // 将数值与状态写回
    this.setData({
      num: num
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})